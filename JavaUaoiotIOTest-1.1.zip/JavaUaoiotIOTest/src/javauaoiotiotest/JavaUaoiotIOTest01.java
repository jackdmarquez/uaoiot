/* ESTE ES UN EJEMPLO QUE UTILIZA LOS MÉTODOS publishDataThread y modifyDataThread
 * QUE SE UTILIZA DENTRO DE LOS METODOS CALLBACK onPublishData y onModifyData
 * EN ESTE EJEMPLO RECIBE UN VALOR ALEATORIO DEL ARDUINO ENTRE 0 Y 100
 * SI ESTE ES MAYOR QUE 50 DEVUELVE AL ARDUINO UN VALOR DE 0 POR EL REGISTRO 1 
 * SI NO DEVUELVE AL ARDUINO UN VALOR DE 0 POR EL REGISTRO 1
 */
package javauaoiotiotest;

import co.edu.uao.uaoiot.javauaoiotlib.UaoiotCallback;
import co.edu.uao.uaoiot.javauaoiotlib.UaoiotClient;
import org.eclipse.paho.client.mqttv3.MqttException;

/**
 *
 * @author jhonep
 */
public class JavaUaoiotIOTest01 {

    private static int onModifyDataRegister, onModifyDataValue;
    private static int onPublishDataRegister, onPublishDataValue;

    public static void main(String[] args) throws MqttException {

        UaoiotClient uaoiotClient = new UaoiotClient();;
        //uaoiotClient.connect("172.16.3.27", "apptest01", "grupo1", "123456");//IP INTERNA UAOIOT
        uaoiotClient.connect("181.118.150.147", "apptest01", "grupo1", "123456");//IP EXTERNA UAOIOT
        //uaoiotClient.connect("192.168.0.15", "apptest01", "grupo1", "123456");//RASPBERRY PRUEBAS LOCALES
        System.out.println("conectado al servidor");
        uaoiotClient.addDevice("ardtest01");

        uaoiotClient.setUaoiotCallback(new UaoiotCallback() {

            @Override
            public void onModifyDataArrive(int register, int value) {
                System.out.println("Recibiendo onModifyDataArrive: Register=" + register + ",Value=" + Integer.toHexString(value));
                onModifyDataRegister = register;
                onModifyDataValue = value;
            }

            @Override
            public void onPublishDataArrive(String deviceName, int register, int value) {
                onPublishDataRegister = register;
                onPublishDataValue = value;
                System.out.println("Recibiendo onPublishDataArrive: " + deviceName + "->Register=" + register + ",Value=" + Integer.toHexString(value));
            }
        });

        new Thread() {
            @Override
            public void run() {
                System.out.println("INICIANDO WHILE INFINITO");
                while (true) {
                    if (onPublishDataRegister == 1 && onPublishDataValue > 50) {
                        uaoiotClient.publishDataThread(1, 1, 1000);//PUBLICANDO EL DATO 
                        uaoiotClient.modifyDataThread("ardtest01", 1, 1, 1000);//ENVIANDO DIRECTAMENTE AL DISPOSITIVO ardtest01
                    } else {
                        uaoiotClient.publishDataThread(1, 0, 1000);//PUBLICANDO EL DATO
                        uaoiotClient.modifyDataThread("ardtest01", 1, 0, 1000);//ENVIANDO DIRECTAMENTE AL DISPOSITIVO ardtest01
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {

                    }
                }
            }
        }.start();
    }

}
