/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javauaoiotiotest;

import co.edu.uao.uaoiot.javauaoiotlib.UaoiotCallback;
import co.edu.uao.uaoiot.javauaoiotlib.UaoiotClient;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.paho.client.mqttv3.MqttException;

/**
 *
 * @author jhonep
 */
public class JavaUaoiotIOTest03 {

    public static void main(String[] args) throws MqttException {

        UaoiotClient uaoiotClient = new UaoiotClient();;
        //uaoiotClient.connect("172.16.3.27", "app01", "grupo1", "123456");//IP INTERNA UAOIOT
        uaoiotClient.connect("181.118.150.147", "apptest", "grupo1", "123456");//IP EXTERNA UAOIOT
        //uaoiotClient.connect("192.168.0.15", "appmysql", "grupo1", "123456");//RASPBERRY PRUEBAS LOCALES
        System.out.println("conectado al servidor");
        uaoiotClient.addDevice("ardtest01");

        uaoiotClient.setUaoiotCallback(new UaoiotCallback() {

            @Override
            public void onModifyDataArrive(int i, int i1) {

            }

            @Override
            public void onPublishDataArrive(String deviceName, int register, int value) {
                if (register == 1 && value > 50) {
                    uaoiotClient.publishDataThread(1, 1, 1000);
                } else {
                    uaoiotClient.publishDataThread(1, 0, 1000);
                }
                System.out.println(deviceName + "->Register=" + register + ",Value=" + Integer.toHexString(value));
            }
        });
        new Thread() {
            int contador = 0;

            @Override
            public void run() {
                while (true) {
                    uaoiotClient.publishData(1, contador++);
                    System.out.println("Sending...");
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(JavaUaoiotIOTest03.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }.start();

    }

}
