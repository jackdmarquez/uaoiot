/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uao.uaoiot.examples;

import co.edu.uao.uaoiot.javauaoiotlib.UaoiotCallback;
import co.edu.uao.uaoiot.javauaoiotlib.UaoiotClient;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.eclipse.paho.client.mqttv3.MqttException;

public class MySqlAppTest {

    public static PreparedStatement preparedStatement = null;
    public static Connection conexion;
    public static String createTableSQL = "CREATE TABLE iot_object("
            + "id INT(11) NOT NULL, "
            + "iot_object_name VARCHAR(20) NOT NULL, "
            + "var1 INT(11) NOT NULL, "
            + "var2 INT(11) NOT NULL, "
            + "var3 INT(11) NOT NULL, "
            + "var4 INT(11) NOT NULL, " + "PRIMARY KEY (id) "
            + ")";
    public static int id=1;

    public static void conectar() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/?useServerPrepStmts=true", "root", "");
            preparedStatement = conexion.prepareStatement("DROP DATABASE IF EXISTS uaoiottest ");
            preparedStatement.executeUpdate();
            preparedStatement = conexion.prepareStatement("CREATE DATABASE uaoiottest");
            preparedStatement.executeUpdate();
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/uaoiottest?useServerPrepStmts=true", "root", "");
            preparedStatement = conexion.prepareStatement(createTableSQL);
            preparedStatement.executeUpdate();
            System.out.println("Tabla uaoiottest creada");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public static void crearTabla() {

    }

    public static void guardarDatoDispositivo(String iotObjectId, int register1Value, int register2Value, int register3Value, int register4Value) {
        try {
            preparedStatement = conexion.prepareStatement("insert into iot_object values (?,?,?,?,?,?)");
            preparedStatement.setInt(1, id++); // Nombre del dispositivo.
            preparedStatement.setString(2, iotObjectId); // Nombre del dispositivo.
            preparedStatement.setInt(3, register1Value); // Numero del Registro
            preparedStatement.setInt(4, register2Value); // Valor dle REgistro
            preparedStatement.setInt(5, register3Value); // Valor dle REgistro
            preparedStatement.setInt(6, register4Value); // Valor dle REgistro
            preparedStatement.executeUpdate(); // Se ejecuta la inserción.
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param args the command line arguments
     * @throws org.eclipse.paho.client.mqttv3.MqttException
     */
    public static void main(String[] args) throws MqttException {

        conectar();
        final UaoiotClient uaoiotClient = new UaoiotClient();
        uaoiotClient.connect("172.16.3.27", "java01", "grupo1", "123456");//IP INTERNA UAOIOT
//        uaoiotClient.connect("181.118.150.147", "java01", "grupo1", "123456");//IP EXTERNA UAOIOT
        System.out.println("conectado al servidor");
        uaoiotClient.addIotObjectListener("ard01");

        uaoiotClient.setUaoiotCallback(new UaoiotCallback() {

            @Override
            public void onModifyPrivateRegister(int registerCount) {

            }

            @Override
            public void onPublishDataArrive(String iotObjectId, int registerCount) {
                System.out.println(iotObjectId+"->"+registerCount);
                if (registerCount >= 4) {
                    guardarDatoDispositivo(iotObjectId, uaoiotClient.getPublishedRegisterValue(0), uaoiotClient.getPublishedRegisterValue(1), uaoiotClient.getPublishedRegisterValue(2), uaoiotClient.getPublishedRegisterValue(3));
                }
            }

        });
    }

}
