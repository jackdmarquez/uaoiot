/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uao.uaoiot.examples;

import co.edu.uao.uaoiot.javauaoiotlib.UaoiotCallback;
import co.edu.uao.uaoiot.javauaoiotlib.UaoiotClient;
import org.eclipse.paho.client.mqttv3.MqttException;

public class CleanProyect {



    /**
     * @param args the command line arguments
     * @throws org.eclipse.paho.client.mqttv3.MqttException
     */
    public static void main(String[] args) throws MqttException {

        final UaoiotClient uaoiotClient = new UaoiotClient();
        //uaoiotClient.connect("172.16.3.27", "apptest01", "grupo1", "123456");//IP INTERNA UAOIOT
        uaoiotClient.connect("181.118.150.147", "java01", "grupo1", "123456");//IP EXTERNA UAOIOT
        System.out.println("conectado al servidor");
        //uaoiotClient.addIotObjectListener("ard01");

        uaoiotClient.setUaoiotCallback(new UaoiotCallback() {

            @Override
            public void onModifyPrivateRegister(int i) {

            }

            @Override
            public void onPublishDataArrive(String iotObjectId, int lenght) {

            }

        });
    }

}
