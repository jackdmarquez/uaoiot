package co.edu.uao.uaoiot.examples;

import co.edu.uao.uaoiot.javauaoiotlib.UaoiotCallback;
import co.edu.uao.uaoiot.javauaoiotlib.UaoiotClient;
import org.eclipse.paho.client.mqttv3.MqttException;

/**
 * Esta clase es usada para realizar una prueba de conexión Java con el servidor
 * UAOIOT
 *
 * @author Jhon Eder Portocarrero
 * @version 1.1
 *
 */
public class UaiotClientTestClient1 {

    public static void main(String[] args) throws MqttException {
        final UaoiotClient uaoiotClient = new UaoiotClient();;
        //uaoiotClient.connect("172.16.3.27", "client1", "grupo1", "123456");//IP INTERNA UAOIOT
        uaoiotClient.connect("181.118.150.147", "client1", "grupo1", "123456");//IP EXTERNA UAOIOT
        System.out.println("conectado al servidor");

        uaoiotClient.setUaoiotCallback(new UaoiotCallback() {

            @Override
            public void onModifyPrivateRegister(int registerCount) {
                for (int i = 0; i < registerCount; i++) {
                    System.out.println("Registro=" + i + "Valor=" + uaoiotClient.getPrivateRegisterValue(i));
                }
            }

            @Override
            public void onPublishDataArrive(String deviceName, int registerCount) {

            }

        });
        new Thread() {
            @Override
            public void run() {

                int i = 0;
                while (true) {
                    if (uaoiotClient.isClientConnected()) {
                        uaoiotClient.setTempRegisterValue(0, i * 0.32);
                        uaoiotClient.setTempRegisterValue(1, i * 0.32);
                        uaoiotClient.publishPublicRegisters(2);
                        System.out.println("Enviando...->" + i);
                        i++;
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ex) {

                        }
                        if (i > 100) {
                            i = 0;
                        }
                    }
                }
            }
        }.start();

    }

}
