package co.edu.uao.uaoiot.javauaoiotlib;

/**
 * Esta interface permite que a una aplicación que la implemente se le notifique
 * cuando se producen eventos asíncronos relacionados con el cliente. 
 * @author Jhon Eder Portocarrero
 * @version 1.1
 *
 */
public interface UaoiotCallback {

    /**
     * Este método es llamado cuando llega un mensaje enviado desde otro
     * dispostivo utilizando el método modifyData(...);
     * @param registerCount

     */
    public void onModifyPrivateRegister(int registerCount);

    /**
     * Este método es llamado cuando llega un mensaje enviado desde otro
     * dispostivo utilizando el método publicData(...);
     *
     * @param iotObjectId
     * @param registerCount
     */
    public void onPublishDataArrive(String iotObjectId, int registerCount);
}
