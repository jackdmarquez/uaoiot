package co.edu.uao.uaoiot.javauaoiotlib;

import org.eclipse.paho.client.mqttv3.MqttException;

/**
 * Esta clase es usada para realizar una prueba de conexión Java con el servidor
 * UAOIOT
 *
 * @author Jhon Eder Portocarrero
 * @version 1.1
 *
 */
public class UaiotClientTestClient1 {

    public static void main(String[] args) throws MqttException {
        final UaoiotClient uaoiotClient = new UaoiotClient();;
        uaoiotClient.connect("181.118.150.147", "client1", "grupo1", "123456");
        System.out.println("conectado al servidor");

        uaoiotClient.setUaoiotCallback(new UaoiotCallback() {

            @Override
            public void onModifyPrivateRegister(int registerCount) {

            }

            @Override
            public void onPublishDataArrive(String deviceName, int registerCount) {

            }

        });
        new Thread() {
            @Override
            public void run() {

                int i = 0;
                while (true) {
                    if (uaoiotClient.isClientConnected()) {
                        uaoiotClient.setTempRegisterValue(0, i*0.323456);
                        uaoiotClient.setTempRegisterValue(1, i*0.323456);
                        uaoiotClient.setTempRegisterValue(2, i*0.323456);
                        uaoiotClient.setTempRegisterValue(3, i*0.323456);
                        uaoiotClient.publishPublicRegisters(4);
                         System.out.println("Enviando...->" + i);
                        i++;
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ex) {

                        }
                        if (i > 100) {
                            i = 0;
                        }
                    }
                }
            }
        }.start();

    }

}
