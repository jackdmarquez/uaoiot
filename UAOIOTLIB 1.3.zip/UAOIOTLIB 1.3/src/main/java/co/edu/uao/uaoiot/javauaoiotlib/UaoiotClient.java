package co.edu.uao.uaoiot.javauaoiotlib;


import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

/**
 * Esta clase crea un cliente MQTT el cual permite la conexión con el BROKER
 * UAOIOT
 *
 * @author Jhon Eder Portocarrero
 * @version 1.1
 *
 */
public class UaoiotClient implements MqttCallback {

    private MqttClient mqttClient;
    private String userName, iotObjectId;
    private UaoiotCallback uaoiotCallback;
    private final double[] privateRegisters = new double[128];
    private final double[] publishedRegisters = new double[128];
    private final double[] tempRegisters = new double[128];
    private boolean clientConnected = false;

    /**
     *
     */
    public UaoiotClient() {

    }

    /**
     * Método para definir que clase va a utilizar el UaoiotCallback y sus
     * respectivos métodos Esta clase crea un cliente MQTT el cual permite la
     * conexión con el BROKER
     *
     * @param uaoiotCallback
     */
    public void setUaoiotCallback(UaoiotCallback uaoiotCallback) {
        this.uaoiotCallback = uaoiotCallback;
    }

    /**
     * Método utilizado para conectarse al broker UAOIOT
     *
     * @param host Dirección IP del Broker UAIOT
     * @param iotObjectId
     * @param userName Nombre de Usuario utilizado para las credenciales de
     * conexión al broker.
     * @param password Contraseña utilizada para las credenciales de conexión al
     * broker.
     * @throws org.eclipse.paho.client.mqttv3.MqttException
     */
    public void connect(String host, final String iotObjectId, final String userName, String password) throws MqttException {
        this.userName = userName;
        this.iotObjectId = iotObjectId;
        mqttClient = new MqttClient("tcp://" + host + ":1883", userName + "_" + iotObjectId);
        MqttConnectOptions connOpts = new MqttConnectOptions();
        connOpts.setUserName(userName);
        connOpts.setPassword(password.toCharArray());
        connOpts.setCleanSession(true);
        mqttClient.connect(connOpts);
        mqttClient.setCallback(this);
        mqttClient.subscribe("md_" + userName + "_" + iotObjectId);
        clientConnected = true;
    }

    /**
     * Método utilizado para subscribirse a las publicaciones de un dispositivo
     * determinado.
     *
     * @param iotObjectId
     * @throws org.eclipse.paho.client.mqttv3.MqttException
     */
    public void addIotObjectListener(String iotObjectId) throws MqttException {
        mqttClient.subscribe("pb_" + userName + "_" + iotObjectId, 0);
    }

    /**
     * Método utilizado para publicar datos directamente a un dispositivo
     * conocido.
     *
     * @param remoteIotObjectId
     * @param registerCount
     */
    public void modifyRemoteRegisters(String remoteIotObjectId, int registerCount) {
        if (clientConnected) {
            try {
                String message = "";
                for (int i = 0; i < registerCount; i++) {
                    message += tempRegisters[i] + ";";
                }
                mqttClient.publish("md_" + userName + "_" + remoteIotObjectId, message.getBytes(), 0, false);
            } catch (MqttException ex) {
                Logger.getLogger(UaoiotClient.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Método utilizado para realizar una publicación de un (registro:valor).
     *
     * @param registerCount
     */
    public void publishPublicRegisters(int registerCount) {
        if (clientConnected) {
            try {
                String message = "";
                for (int i = 0; i < registerCount; i++) {
                    message += tempRegisters[i] + ";";
                }
                mqttClient.publish("pb_" + userName + "_" + iotObjectId, message.getBytes(), 0, false);
            } catch (MqttException ex) {
                Logger.getLogger(UaoiotClient.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void setPrivateRegisterValue(int i, double value) {
        privateRegisters[i] = value;
    }

    public void setTempRegisterValue(int i, double value) {
        tempRegisters[i] = value;
    }

    public double getPrivateRegisterValue(int i) {
        return privateRegisters[i];
    }

    public double getPublishedRegisterValue(int i) {
        return publishedRegisters[i];
    }

    /**
     * Método llamado automaticamente cuando se pierde la conexión
     *
     * @param cause Parámetro que indica la causa de la perdida de conexión
     */
    @Override
    public void connectionLost(Throwable cause) {
        System.out.println("Conexión Perdida");
        clientConnected = false;
    }

    /**
     * Se llama cuando la entrega de un mensaje se ha completado, y se han
     * recibido todos los reconocimientos. Para QoS 0 mensajes que se llama una
     * vez que el mensaje ha sido entregado a la red para la entrega. Para QoS 1
     * se le llama cuando se recibe PUBACK y de calidad de servicio 2 cuando se
     * recibe PUBCOMP. El contador será la misma razón que el devuelto cuando se
     * publicó el mensaje
     *
     * @param token
     */
    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        try {
            if (topic.equals("md_" + userName + "_" + iotObjectId)) {
                String messageText = message.toString();
                String[] messageSplitText = messageText.split(";");
                for (int i = 0; i < messageSplitText.length; i++) {
                    privateRegisters[i] = Double.valueOf(messageSplitText[i]);
                }
                uaoiotCallback.onModifyPrivateRegister(messageSplitText.length);
            } else {
                String messageText = message.toString();
                String[] messageSplitText = messageText.split(";");
                for (int i = 0; i < messageSplitText.length; i++) {
                    publishedRegisters[i] = Double.valueOf(messageSplitText[i]);
                }
                String[] topicSplit = topic.split("_");
                if (topicSplit.length == 3 && topicSplit[2] != null) {
                    String deviceNameTmp = topicSplit[2];
                    uaoiotCallback.onPublishDataArrive(deviceNameTmp, messageSplitText.length);
                }
            }
        } catch (NumberFormatException e) {

        }
    }

    public void disconnect() {
        try {
            mqttClient.disconnect();
        } catch (MqttException ex) {
            Logger.getLogger(UaoiotClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean isClientConnected() {
        return clientConnected;
    }

}
