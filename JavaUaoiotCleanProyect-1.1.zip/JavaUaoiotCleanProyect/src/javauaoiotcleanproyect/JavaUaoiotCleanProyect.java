/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javauaoiotcleanproyect;

import co.edu.uao.uaoiot.javauaoiotlib.UaoiotCallback;
import co.edu.uao.uaoiot.javauaoiotlib.UaoiotClient;
import org.eclipse.paho.client.mqttv3.MqttException;

/**
 *
 * @author jhonep
 */
public class JavaUaoiotCleanProyect {

  public static void main(String[] args) throws MqttException {

        UaoiotClient uaoiotClient = new UaoiotClient();;
        uaoiotClient.connect("172.16.3.27", "appmysql", "grupo1", "123456");//IP INTERNA UAOIOT
        //uaoiotClient.connect("181.118.150.147", "appmysql", "grupo1", "123456");//IP EXTERNA UAOIOT
        //uaoiotClient.connect("192.168.0.2", "appmysql", "grupo1", "123456");//RASPBERRY PRUEBAS LOCALES
        System.out.println("conectado al servidor");

        uaoiotClient.setUaoiotCallback(new UaoiotCallback() {

            @Override
            public void onModifyDataArrive(int i, int i1) {

            }

            @Override
            public void onPublishDataArrive(String deviceName, int register, int value) {
            
            }
        });
   
    }
    
}
