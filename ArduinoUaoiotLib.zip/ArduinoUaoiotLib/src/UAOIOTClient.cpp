#include "UAOIOTClient.h"
#include "MQTTClient.h"


BridgeClient UAOIOTNet;
MQTTClient UAOIOTclient;
String UAOIOTdeviceName, UAOIOTuserName, UAOIOTpassword;

//void messageReceived(String topic, String payload, char * bytes, unsigned int length){
//    
//}

boolean beginUAOIOT(const char * hostname, const char * _deviceName, const char * _userName, const char * _password) {
    UAOIOTdeviceName = _deviceName;
    UAOIOTuserName = _userName;
    UAOIOTpassword = _password;
    Serial.println("Starting bridge...\n");
    Serial.println("Si el arduino fue reiniciado,\n");
    Serial.println("este proceso durara aproximadamente 40s\n");
    pinMode(13, OUTPUT);
    digitalWrite(13, LOW);
    Bridge.begin(); // make contact with the linux processor
    digitalWrite(13, HIGH); // Led on pin 13 turns on when the bridge is ready    
    UAOIOTclient.begin(hostname, UAOIOTNet);

}

void connectToBroker() {
    Serial.print("connecting...");
    while (!UAOIOTclient.connect(UAOIOTdeviceName.c_str(), UAOIOTuserName.c_str(), UAOIOTpassword.c_str())) {
        Serial.print(".");
    }
    Serial.println("\nconnected!");
    /*Este metodo lo que permite es conectarse al topico app1
     * con el objetivo habilitar la recepci�n de mensajes enviados a
     * este topico. Si el cliente no se conecta a un topico no recibira 
     * mensajes en el metodo void dataReceive();
     */
    UAOIOTclient.subscribe("md_" + UAOIOTuserName + "_" + UAOIOTdeviceName);
}

void addDevice(String deviceName) {
    UAOIOTclient.subscribe("pb_" + UAOIOTuserName + "_" + deviceName);
}
//

void checkConn() {
    UAOIOTclient.loop();
    //  if (!UAOIOTclient.connected()) {
    //connectToBroker();
    //Serial.print("no conectado\n");
    // }

    //   return this->client->connected() == test;
    //   UAOIOTclient.loop();
    //   if (!UAOIOTclient.connected()) {
    //       Serial.print("no conectado\n");
    //       connectToBroker();
    //   }
}

void publishData(int reg, int value) {
    String sfTopic = "pb_" + UAOIOTuserName + "_" + UAOIOTdeviceName;
    // Serial.print("topic->" + sfTopic +";value->"+String(reg)+":"+String(value) +"\n");
    String message = String(reg) + ";" + String(value);
    UAOIOTclient.publish(sfTopic.c_str(), message.c_str());

}

void modifyData(String device, int reg, int value) {
    String sfTopic = "md_" + UAOIOTuserName + "_" + device;
    // Serial.print("topic->" + sfTopic +";value->"+String(reg)+":"+String(value) +"\n");
    String message = String(reg) + ";" + String(value);
    UAOIOTclient.publish(sfTopic.c_str(), message.c_str());

}

void messageReceived(String topic, String payloads) {
    char * payload = (char *) payloads.c_str();
    String stName = "md_" + UAOIOTuserName + "_" + UAOIOTdeviceName;
    char* reg;
    char* value;
    if (String(topic) == stName) {
        reg = strtok(payload, ";");
        if (reg != NULL) {
            value = strtok(NULL, ";");
            if (value != NULL) {
                onModifyDataArrive((String(reg)).toInt(), (String(value)).toInt());
            }
        }
    } else {
        String remoteDeviceName, reg, value;
        strtok((char *) topic.c_str(), "_");
        strtok(NULL, "_");
        remoteDeviceName = strtok(NULL, "_");
        reg = strtok(payload, ";");
        if (reg != NULL) {
            value = strtok(NULL, ";");
            if (value != NULL) {
                onPublishDataArrive(remoteDeviceName, String(reg).toInt(), (String(value)).toInt());
            }
        }
    }
}

