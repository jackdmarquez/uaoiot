#ifndef UAOIOT_CLIENT_H
#define UAOIOT_CLIENT_H
#include <BridgeClient.h>
#include <MQTTClient.h>

//void messageReceived(String topic, String payload, char * bytes, unsigned int length);
boolean beginUAOIOT(const char * hostname, const char * _deviceName, const char * _userName, const char * _password);
void connectToBroker(void);
void checkConn();
void setLocalRegisterValue(int nReg,int value);
void setRemoteRegisterValue(String deviceName,int nReg,int value);
void sendLocalRegisterValue(String deviceName,int nReg);
void requestRemoteRegisterValue(String deviceName,int nReg);
void publishData(int idRegister,int value);
void modifyData(String deviceName, int idRegister,int value);
void onPublishDataArrive(String remoteDeviceName,int idRegister,int value);
void onModifyDataArrive(int idRegister,int value);
void addDevice(String deviceName);


#endif
