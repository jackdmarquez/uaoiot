/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javauaoiotmysqlapptest;

import co.edu.uao.uaoiot.javauaoiotlib.UaoiotCallback;
import co.edu.uao.uaoiot.javauaoiotlib.UaoiotClient;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.eclipse.paho.client.mqttv3.MqttException;

public class JavaUaoiotMySQLAppTest {

    public static PreparedStatement psInsertar = null;
    public static Connection conexion;

    public static void conectar() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/uaoiotmysqltest?useServerPrepStmts=true",
                    "rootuao", "Uaoiot2016");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void guardarDatoDispositivo(String deviceName, int register, int value) throws ClassNotFoundException {
        try {
            psInsertar = conexion.prepareStatement(
                    "insert into device values (null,?,?,?)");
            psInsertar.setString(1, deviceName); // Nombre del dispositivo.
            psInsertar.setInt(2, register); // Numero del Registro
            psInsertar.setInt(3, value); // Valor dle REgistro
            psInsertar.executeUpdate(); // Se ejecuta la inserción.
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param args the command line arguments
     * @throws org.eclipse.paho.client.mqttv3.MqttException
     */
    public static void main(String[] args) throws MqttException {

        conectar();
        UaoiotClient uaoiotClient = new UaoiotClient();;
        //uaoiotClient.connect("172.16.3.27", "apptest01", "grupo1", "123456");//IP INTERNA UAOIOT
        uaoiotClient.connect("181.118.150.147", "apptest01", "grupo1", "123456");//IP EXTERNA UAOIOT
        //uaoiotClient.connect("192.168.0.2", "apptest01", "grupo1", "123456");//RASPBERRY PRUEBAS LOCALES
        System.out.println("conectado al servidor");
        uaoiotClient.addDevice("ardtest01");

        uaoiotClient.setUaoiotCallback(new UaoiotCallback() {

            @Override
            public void onModifyDataArrive(int register, int value) {
                System.out.println("Recibiendo onModifyDataArrive: Register=" + register + ",Value=" + Integer.toHexString(value));
            }

            @Override
            public void onPublishDataArrive(String deviceName, int register, int value) {
                System.out.println("Recibiendo onPublishDataArrive: " + deviceName + "->Register=" + register + ",Value=" + Integer.toHexString(value));
                try {
                    guardarDatoDispositivo(deviceName, register, value);
                } catch (ClassNotFoundException ex) {

                }
            }

        });
    }

}
